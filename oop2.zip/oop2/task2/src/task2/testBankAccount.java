package task2;

public class testBankAccount {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		 BankAccount Account1 =new BankAccount();
	        System.out.println("Account num:"+Account1.getbalance());
	        System.out.println("Balance:"+Account1.getbalance());
	        System.out.println("Customer Name:"+Account1.getbalance());
	        
	        
	        BankAccount Account2 =new BankAccount(146,1250.0,"Ahmad");
	        System.out.println("Account num:"+Account2.getbalance());
	        System.out.println("Balance:"+Account2.getbalance());
	        System.out.println("Customer Name:"+Account2.getbalance());
	        
	        BankAccount Account3 =new BankAccount(1250.0);
	        System.out.println("Account num:"+Account3.getbalance());
	        System.out.println("Balance:"+Account3.getbalance());
	        System.out.println("Customer Name:"+Account3.getbalance());
	        //deposit 1000 for each account
	        
	        Account1.deposit(1000.0);
	        Account2.deposit(1000.0);
	        Account3.deposit(1000.0);
	        //After deposit 1000 for each account
	        
	        System.out.println(" Acoount1 Balance:"+Account1.getbalance());
	        System.out.println(" Acoount2 Balance:"+Account2.getbalance());
	        System.out.println("Acoount3 Balance:"+Account3.getbalance());
	        
	        //withdrow for each account
	        Account1.withdrow(100.0);
	        Account2.withdrow(200.0);
	        Account3.withdrow(100.0);
	        // After wihdrow
	        System.out.println(" Acoount1 Balance:"+Account1.getbalance());
	        System.out.println(" Acoount2 Balance:"+Account2.getbalance());
	        System.out.println("Acoount3 Balance:"+Account3.getbalance());
	        
	        //Change customer name
	        Account3.setcustomerName("Mustafa");
	        System.out.println("Acoount3 new name:"+Account3.getcustomerName());
	        

	}

}
