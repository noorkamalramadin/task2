package task2;

public class BankAccount {
	private int accountNum;
	private double balance;
	private String customerName;
	
    public BankAccount()//constructor1
    {
	  accountNum=0;
	  balance=0.0;
	  customerName="";
    }
    public BankAccount(int accNum,double balan,String cusName)//constructor2
    {
    	accountNum=accNum;
    	balance=balan;
    	customerName=cusName;
    }
    public BankAccount(double balan)//constructor3 يستقبل ففط ال balance
    {
    	 accountNum=0;
    	balance=balan;
    	customerName="";
    }
    public void setAccountNumber(int accNum) //Set
    {
    	accountNum=accNum;
    }
    public void setbalance(double balan)
    {
    	balance=balan;}
    public void setcustomerName(String Name) 
     {
    	customerName=Name;
     }
    //get
    public int getaccountNum()
    {
    	return accountNum;
    }
    public double getbalance() {return balance;}
    public String getcustomerName() {return customerName; }
    //method withdrow السحب من الحساب 
    public void withdrow( double amount)
    {
    	balance= balance-amount;
    }
    public void deposit(double amount)//depositللايداع 
    {
    	
    	balance= balance+amount;
    }
    public void reset()
    {
    	balance=0;
    }
    
   
    }// end of class1
    
   
