/**
 * 
 */
/**
 * 
 */
module task2 {
}